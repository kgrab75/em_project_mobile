(function(context) {

    var app = {


    };

    context.app = app;

})(window);
